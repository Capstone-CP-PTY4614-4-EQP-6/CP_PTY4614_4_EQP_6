import React, { useState } from 'react';
import RegistroComponent from '../components/RegistroComponent';


function RegistroPage() {
  return (
    <React.Fragment>
      <RegistroComponent/>
    </React.Fragment>
    
  )
}
export default RegistroPage;

