import React from 'react';
import CitasComponent from '../components/citas/RegistrarCitas';

const CitasPage = () => {
    return (
        <React.Fragment>
            <CitasComponent />
        </React.Fragment>
        
    )
}

export default CitasPage