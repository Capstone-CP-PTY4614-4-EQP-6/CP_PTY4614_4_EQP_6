import React from 'react';
import LoginComponent from '../components/LoginComponent';


const LoginPage = () => {

    return (
      <React.Fragment>
        <LoginComponent />
      </React.Fragment>
      
    )
  }

export default LoginPage;

