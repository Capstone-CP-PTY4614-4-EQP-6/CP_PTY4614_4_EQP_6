/**
 * Componente para registrar un pago.
 * 
 * Este componente permite registrar un pago con su monto, método de pago,
 * fecha de pago y estado de pago.
 * 
 * @returns Un formulario para registrar un pago.
 */
const RegistrarPago = () => {
  /**
   * Estado del monto del pago.
   * 
   * @type {string}
   */
  const [monto, setMonto] = React.useState('');

  /**
   * Estado del método de pago.
   * 
   * @type {string}
   */
  const [metodo_pago, setMetodoPago] = React.useState('');

  /**
   * Estado de la fecha de pago.
   * 
   * @type {string}
   */
  const [fecha_pago, setFechaPago] = React.useState('');

  /**
   * Estado del estado de pago.
   * 
   * @type {string}
   */
  const [estado_pago, setEstadoPago] = React.useState('');

  /**
   * Función para manejar el envío del formulario.
   * 
   * @param {Event} event Evento de envío del formulario.
   */
  const handleSubmit = (event) => {
    event.preventDefault();
    // Enviar el formulario al servidor
    console.log('Formulario enviado');
  };

  return (
    <Grid container>
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
        <Typography variant="h2">Registrar Pago</Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            label="Monto"
            value={monto}
            onChange={(event) => setMonto(event.target.value)}
            fullWidth
            /**
             * Atributo para darle un nombre al campo en el formulario.
             * 
             * @type {string}
             */
            name="monto"
          />
          <TextField
            label="Método de Pago"
            value={metodo_pago}
            onChange={(event) => setMetodoPago(event.target.value)}
            fullWidth
            name="metodo_pago"
          />
          <TextField
            label="Fecha de Pago"
            value={fecha_pago}
            onChange={(event) => setFechaPago(event.target.value)}
            fullWidth
            name="fecha_pago"
          />
          <TextField
            label="Estado de Pago"
            value={estado_pago}
            onChange={(event) => setEstadoPago(event.target.value)}
            fullWidth
            name="estado_pago"
          />
          <Button variant="contained" color="primary" type="submit">
            Registrar Pago
          </Button>
        </form>
      </Grid>
    </Grid>
  );
};

/**
 * Exportar el componente como default.
 */
export default RegistrarPago;
